
---@class ed_barline : button
---@field statusBar statusbar
---@field lineText1 fontstring
---@field lineText4 fontstring
---@field statusBarTexture texture
---@field Icon texture

