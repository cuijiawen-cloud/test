# Details! Damage Meter

## [Details.20251023.13811.166](https://github.com/Tercioo/Details-Damage-Meter/tree/Details.20251023.13811.166) (2025-10-23)
[Full Changelog](https://github.com/Tercioo/Details-Damage-Meter/compare/Details.20251021.13809.166...Details.20251023.13811.166) 

- Fixes for Classic and Remix  
    Flamanis:  
    - Fix an issue with role assignment in vanilla wow.  
    - Fix error in remix mythic plus dungeons where one of the affixes is sanguine.  
- Readd sanguine special unit cause lemix  
- Ignore path helper  
- Framework Update  
- Don't use GetSpecializationRole on classic era cause blizz makes it error  
