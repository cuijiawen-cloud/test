
local Details = Details
local addonName, Details222 = ...
---@type detailsframework
local detailsFramework = DetailsFramework
local _

local sharedMedia = LibStub("LibSharedMedia-3.0")

---@type details_allinonewindow
local AllInOneWindow = Details222.AllInOneWindow

local icons = AllInOneWindow.Icons

